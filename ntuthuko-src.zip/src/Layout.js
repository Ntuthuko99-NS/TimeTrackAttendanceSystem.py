import { NavLink } from 'react-router-dom';
const links = [['/', 'Dashboard'], ['/employees', 'Employees'], ['/shifts', 'Shifts'], ['/leave', 'Leave'], ['/timesheet', 'Timesheet'], ['/reports', 'Reports'], ['/alerts', 'Alerts'], ['/whatsapp', 'WhatsApp'], ['/settings', 'Settings'], ['/profile', 'My profile']];
export default function Layout({ children }) {
  return (
    <div className="min-h-screen bg-gray-50 md:flex">
      <nav className="md:w-52 bg-white border-r p-3 flex md:block gap-2 overflow-x-auto">
        {links.map(([to, label]) => <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => `block px-3 py-2 rounded text-sm whitespace-nowrap ${isActive ? 'bg-emerald-700 text-white' : 'hover:bg-gray-100'}`}>{label}</NavLink>)}
      </nav>
      <main className="flex-1 p-4 md:p-6 max-w-5xl">{children}</main>
    </div>
  );
}
