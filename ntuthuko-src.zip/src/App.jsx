import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './Layout';
import Dashboard from './pages/Dashboard';
import Employees from './pages/Employees';
import Shifts from './pages/Shifts';
import Leave from './pages/Leave';
import Timesheet from './pages/Timesheet';
import Reports from './pages/Reports';
import Alerts from './pages/Alerts';
import WhatsAppConnects from './pages/WhatsAppConnects';
import Settings from './pages/Settings';
import MyProfile from './pages/MyProfile';
export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} /><Route path="/employees" element={<Employees />} />
          <Route path="/shifts" element={<Shifts />} /><Route path="/leave" element={<Leave />} />
          <Route path="/timesheet" element={<Timesheet />} /><Route path="/reports" element={<Reports />} />
          <Route path="/alerts" element={<Alerts />} /><Route path="/whatsapp" element={<WhatsAppConnects />} />
          <Route path="/settings" element={<Settings />} /><Route path="/profile" element={<MyProfile />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
