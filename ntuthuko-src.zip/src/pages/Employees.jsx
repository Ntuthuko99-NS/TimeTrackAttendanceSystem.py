import { useState } from 'react';
import { ntuthukoClient as c } from '../api/ntuthukoClient';
import { useEntity } from '../api/useEntity';
import { Title, Btn } from '../components/ui';
import EmployeeCard from '../components/EmployeeCard';
import EmployeeForm from '../components/EmployeeForm';
export default function Employees() {
  const [list, load] = useEntity('Employee');
  const [edit, setEdit] = useState(null);
  const save = async (d) => { d.id ? await c.entities.Employee.update(d.id, d) : await c.entities.Employee.create(d); setEdit(null); load(); };
  const del = async (e) => { await c.entities.Employee.delete(e.id); load(); };
  return (
    <div className="space-y-4">
      <Title>Employees</Title>
      {edit ? <EmployeeForm initial={edit} onSave={save} onCancel={() => setEdit(null)} /> : <Btn onClick={() => setEdit({})}>Add employee</Btn>}
      <div className="grid md:grid-cols-3 gap-4">{list.map((e) => <EmployeeCard key={e.id} employee={e} onEdit={setEdit} onDelete={del} />)}</div>
      {list.length === 0 && <p className="text-gray-500">No employees yet. Add your first one.</p>}
    </div>
  );
}
