import { useEntity, useMe } from '../api/useEntity';
import { Title, Card, hours } from '../components/ui';
import ClockWidget from '../components/ClockWidget';
export default function MyProfile() {
  const me = useMe(); const [entries] = useEntity('TimeEntry');
  if (!me) return null;
  const total = entries.filter((e) => e.employee_id === me.id).reduce((s, e) => s + hours(e), 0);
  return (
    <div className="space-y-4">
      <Title>My profile</Title>
      <Card><p className="font-medium">{me.full_name}</p><p className="text-sm text-gray-600">{me.email} - {me.role}</p><p className="text-sm mt-2">Total hours logged: {total.toFixed(1)}</p></Card>
      <ClockWidget employee={me} />
    </div>
  );
}
