import { ntuthukoClient as c } from '../api/ntuthukoClient';
import { useEntity } from '../api/useEntity';
import { Title, Card, Btn } from '../components/ui';
import ShiftForm from '../components/ShiftForm';
export default function Shifts() {
  const [shifts, load] = useEntity('Shift'), [employees] = useEntity('Employee');
  const save = async (d) => { await c.entities.Shift.create(d); load(); };
  const del = async (s) => { await c.entities.Shift.delete(s.id); load(); };
  return (
    <div className="space-y-4">
      <Title>Shifts</Title>
      <ShiftForm employees={employees} onSave={save} />
      {[...shifts].sort((a, b) => a.date.localeCompare(b.date)).map((s) => (
        <Card key={s.id} className="flex justify-between items-center">
          <span className="text-sm">{s.date} {s.start_time}-{s.end_time}: {employees.find((e) => e.id === s.employee_id)?.full_name}</span>
          <Btn className="bg-red-700" onClick={() => del(s)}>Delete</Btn>
        </Card>
      ))}
    </div>
  );
}
