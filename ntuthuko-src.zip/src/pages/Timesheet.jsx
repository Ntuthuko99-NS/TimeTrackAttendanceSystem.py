import { useState } from 'react';
import { useEntity } from '../api/useEntity';
import { Title, Select } from '../components/ui';
import TimesheetTable from '../components/TimesheetTable';
export default function Timesheet() {
  const [entries] = useEntity('TimeEntry'), [employees] = useEntity('Employee');
  const [who, setWho] = useState('');
  const rows = entries.filter((e) => !who || e.employee_id === who).sort((a, b) => b.clock_in.localeCompare(a.clock_in));
  return (
    <div className="space-y-4">
      <Title>Timesheet</Title>
      <Select label="Employee" value={who} onChange={(e) => setWho(e.target.value)} options={[{ value: '', label: 'All employees' }, ...employees.map((e) => ({ value: e.id, label: e.full_name }))]} />
      <TimesheetTable entries={rows} employees={employees} />
    </div>
  );
}
