import { useEntity } from '../api/useEntity';
import { AlertService } from '../services/AlertService';
import { Title } from '../components/ui';
import AlertPanels from '../components/AlertPanels';
export default function Alerts() {
  const [alerts, load] = useEntity('Alert');
  const read = async (a) => { await AlertService.markRead(a.id); load(); };
  return <div className="space-y-3"><Title>Alerts</Title><AlertPanels alerts={[...alerts].reverse()} onRead={read} /></div>;
}
