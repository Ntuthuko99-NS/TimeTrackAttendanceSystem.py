import { useEntity } from '../api/useEntity';
import { Title, Card, hours } from '../components/ui';
export default function Reports() {
  const [entries] = useEntity('TimeEntry'), [employees] = useEntity('Employee'), [settings] = useEntity('CompanySettings');
  const cap = settings[0]?.overtime_threshold_hours ?? 40;
  const rows = employees.map((e) => {
    const mine = entries.filter((x) => x.employee_id === e.id);
    const total = mine.reduce((s, x) => s + hours(x), 0);
    return { e, days: new Set(mine.map((x) => x.date)).size, total, overtime: Math.max(0, total - cap) };
  });
  return (
    <div className="space-y-4">
      <Title>Reports</Title>
      <Card>
        <table className="w-full text-sm">
          <thead><tr className="text-left border-b"><th className="py-2">Employee</th><th>Days worked</th><th>Total hours</th><th>Overtime hours</th></tr></thead>
          <tbody>{rows.map((r) => <tr key={r.e.id} className="border-b"><td className="py-2">{r.e.full_name}</td><td>{r.days}</td><td>{r.total.toFixed(1)}</td><td>{r.overtime.toFixed(1)}</td></tr>)}</tbody>
        </table>
        {rows.length === 0 && <p className="text-sm text-gray-500">Add employees and time entries to see reports.</p>}
      </Card>
    </div>
  );
}
