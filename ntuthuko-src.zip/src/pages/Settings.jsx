import { useEffect, useState } from 'react';
import { ntuthukoClient as c } from '../api/ntuthukoClient';
import { Title, Card, Btn, Input } from '../components/ui';
export default function Settings() {
  const [f, setF] = useState({ company_name: '', standard_hours_per_day: 8, overtime_threshold_hours: 40, annual_leave_days: 15, sick_leave_days: 30, late_grace_minutes: 10 });
  const [saved, setSaved] = useState(false);
  useEffect(() => { c.entities.CompanySettings.list().then((l) => l[0] && setF(l[0])); }, []);
  const num = (k) => (e) => setF({ ...f, [k]: +e.target.value });
  const save = async () => { f.id ? await c.entities.CompanySettings.update(f.id, f) : setF(await c.entities.CompanySettings.create(f)); setSaved(true); };
  return (
    <div className="space-y-4">
      <Title>Settings</Title>
      <Card>
        <Input label="Company name" value={f.company_name || ''} onChange={(e) => setF({ ...f, company_name: e.target.value })} />
        <Input label="Standard hours per day" type="number" value={f.standard_hours_per_day} onChange={num('standard_hours_per_day')} />
        <Input label="Overtime after (hours per week)" type="number" value={f.overtime_threshold_hours} onChange={num('overtime_threshold_hours')} />
        <Input label="Annual leave days" type="number" value={f.annual_leave_days} onChange={num('annual_leave_days')} />
        <Input label="Sick leave days" type="number" value={f.sick_leave_days} onChange={num('sick_leave_days')} />
        <Input label="Late grace (minutes)" type="number" value={f.late_grace_minutes} onChange={num('late_grace_minutes')} />
        <Btn onClick={save}>Save settings</Btn>{saved && <span className="ml-2 text-sm text-emerald-700">Saved</span>}
      </Card>
    </div>
  );
}
