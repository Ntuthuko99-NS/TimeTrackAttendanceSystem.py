import { useEntity, useMe } from '../api/useEntity';
import { Title } from '../components/ui';
import ClockWidget from '../components/ClockWidget';
import DashboardStatCard from '../components/DashboardStatCard';
import DashboardActiveEmployees from '../components/DashboardActiveEmployees';
import DashboardRecentActivity from '../components/DashboardRecentActivity';
import TeamAvailability from '../components/TeamAvailability';
export default function Dashboard() {
  const me = useMe();
  const [employees] = useEntity('Employee'), [entries] = useEntity('TimeEntry'), [leave] = useEntity('LeaveRequest'), [alerts] = useEntity('Alert');
  return (
    <div className="space-y-4">
      <Title>Dashboard</Title>
      {me && <ClockWidget employee={me} />}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <DashboardStatCard label="Employees" value={employees.length} />
        <DashboardStatCard label="Clocked in" value={entries.filter((e) => !e.clock_out).length} />
        <DashboardStatCard label="Pending leave" value={leave.filter((l) => l.status === 'pending').length} />
        <DashboardStatCard label="Unread alerts" value={alerts.filter((a) => !a.read).length} />
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        <DashboardActiveEmployees entries={entries} employees={employees} />
        <DashboardRecentActivity entries={entries} employees={employees} />
      </div>
      <TeamAvailability employees={employees} entries={entries} leave={leave} />
    </div>
  );
}
