import { useEffect, useState } from 'react';
import { ntuthukoClient as c } from '../api/ntuthukoClient';
import { AlertService } from '../services/AlertService';
import { Title, Card, Btn, Input } from '../components/ui';
// Stores the connection settings and builds click-to-chat links. Sending automated
// messages needs the WhatsApp Business Cloud API on a server; do not put tokens in the browser.
export default function WhatsAppConnects() {
  const [s, setS] = useState({ whatsapp_enabled: false, whatsapp_number: '' });
  useEffect(() => { c.entities.CompanySettings.list().then((l) => l[0] && setS(l[0])); }, []);
  const save = async () => { s.id ? await c.entities.CompanySettings.update(s.id, s) : setS(await c.entities.CompanySettings.create(s)); AlertService.create('system', 'WhatsApp settings updated'); };
  const link = `https://wa.me/${(s.whatsapp_number || '').replace(/\D/g, '')}?text=${encodeURIComponent('Test message from the time clock app')}`;
  return (
    <div className="space-y-4">
      <Title>WhatsApp</Title>
      <Card>
        <label className="flex items-center gap-2 text-sm mb-2"><input type="checkbox" checked={!!s.whatsapp_enabled} onChange={(e) => setS({ ...s, whatsapp_enabled: e.target.checked })} />Enable WhatsApp notifications</label>
        <Input label="Business number (with country code, e.g. 27821234567)" value={s.whatsapp_number || ''} onChange={(e) => setS({ ...s, whatsapp_number: e.target.value })} />
        <div className="flex gap-2 items-center"><Btn onClick={save}>Save WhatsApp settings</Btn>{s.whatsapp_number && <a className="text-sm underline" href={link} target="_blank" rel="noreferrer">Open test chat</a>}</div>
      </Card>
    </div>
  );
}
