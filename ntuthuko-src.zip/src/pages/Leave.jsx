import { ntuthukoClient as c } from '../api/ntuthukoClient';
import { useEntity, useMe } from '../api/useEntity';
import { Title } from '../components/ui';
import LeaveBalanceCard from '../components/LeaveBalanceCard';
import LeaveRequestCard from '../components/LeaveRequestCard';
import LeaveRequestForm from '../components/LeaveRequestForm';
import LeaveCalendar from '../components/LeaveCalendar';
export default function Leave() {
  const me = useMe();
  const [reqs, load] = useEntity('LeaveRequest'), [employees] = useEntity('Employee'), [settings] = useEntity('CompanySettings');
  const mine = reqs.filter((r) => r.employee_id === me?.id);
  const save = async (d) => { await c.entities.LeaveRequest.create(d); load(); };
  const review = async (r, status) => { await c.entities.LeaveRequest.update(r.id, { status }); load(); };
  if (!me) return null;
  return (
    <div className="space-y-4">
      <Title>Leave</Title>
      <div className="grid md:grid-cols-2 gap-4"><LeaveBalanceCard requests={mine} settings={settings[0]} /><LeaveRequestForm employee={me} onSave={save} /></div>
      <LeaveCalendar requests={reqs} />
      <h2 className="font-medium">{me.role === 'admin' ? 'All requests' : 'My requests'}</h2>
      {(me.role === 'admin' ? reqs : mine).map((r) => <LeaveRequestCard key={r.id} request={r} employee={employees.find((e) => e.id === r.employee_id) || me} onReview={me.role === 'admin' ? review : null} />)}
    </div>
  );
}
