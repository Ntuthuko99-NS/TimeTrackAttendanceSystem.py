import { ntuthukoClient } from '../api/ntuthukoClient';
const A = ntuthukoClient.entities.Alert;
export const AlertService = {
  create: (type, message, employee_id) => A.create({ type, message, employee_id, read: false }),
  unread: () => A.filter({ read: false }),
  markRead: (id) => A.update(id, { read: true }),
  async checkLate(employee, shift, clockIn, graceMin = 10) {
    const due = new Date(`${shift.date}T${shift.start_time}`).getTime() + graceMin * 60000;
    if (new Date(clockIn).getTime() > due) return this.create('late', `${employee.full_name} clocked in late`, employee.id);
  },
};
