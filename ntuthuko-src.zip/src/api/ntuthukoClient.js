// Minimal localStorage-backed client. Replace internals with your real backend; keep the same shape.
const store = (name) => {
  const k = 'ntk_' + name;
  const read = () => JSON.parse(localStorage.getItem(k) || '[]');
  const write = (v) => localStorage.setItem(k, JSON.stringify(v));
  return {
    list: async () => read(),
    filter: async (q) => read().filter((x) => Object.entries(q).every(([a, b]) => x[a] === b)),
    create: async (d) => { const x = { ...d, id: crypto.randomUUID(), created_date: new Date().toISOString() }; write([...read(), x]); return x; },
    update: async (id, d) => write(read().map((x) => (x.id === id ? { ...x, ...d } : x))),
    delete: async (id) => write(read().filter((x) => x.id !== id)),
  };
};
export const ntuthukoClient = {
  entities: Object.fromEntries(['Employee', 'Shift', 'TimeEntry', 'LeaveRequest', 'Alert', 'CompanySettings'].map((n) => [n, store(n)])),
  auth: { me: async () => JSON.parse(localStorage.getItem('ntk_me') || '{"id":"me","full_name":"Demo User","email":"demo@example.com","role":"admin"}') },
};
