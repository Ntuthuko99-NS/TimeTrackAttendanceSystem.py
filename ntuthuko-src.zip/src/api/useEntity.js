import { useEffect, useState } from 'react';
import { ntuthukoClient } from './ntuthukoClient';
export const useEntity = (name) => {
  const [items, setItems] = useState([]);
  const load = () => ntuthukoClient.entities[name].list().then(setItems);
  useEffect(() => { load(); }, []);
  return [items, load];
};
export const useMe = () => {
  const [me, setMe] = useState(null);
  useEffect(() => { ntuthukoClient.auth.me().then(setMe); }, []);
  return me;
};
