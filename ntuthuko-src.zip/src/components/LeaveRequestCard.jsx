import { Card, Btn } from './ui';
export default function LeaveRequestCard({ request: r, employee, onReview }) {
  return (
    <Card className="flex justify-between items-center">
      <div className="text-sm">
        <p className="font-medium">{employee?.full_name} - {r.leave_type} ({r.days} days)</p>
        <p className="text-gray-600">{r.start_date} to {r.end_date} - {r.status}</p>
        {r.reason && <p className="text-gray-600">{r.reason}</p>}
      </div>
      {onReview && r.status === 'pending' && <div className="flex gap-2"><Btn onClick={() => onReview(r, 'approved')}>Approve</Btn><Btn className="bg-red-700" onClick={() => onReview(r, 'rejected')}>Reject</Btn></div>}
    </Card>
  );
}
