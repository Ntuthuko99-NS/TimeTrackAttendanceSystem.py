import { Card, Btn } from './ui';
export default function EmployeeCard({ employee: e, onEdit, onDelete }) {
  return (
    <Card>
      <p className="font-medium">{e.full_name}</p>
      <p className="text-sm text-gray-600">{e.role} {e.department && `- ${e.department}`}</p>
      <p className="text-sm text-gray-600">{e.email} {e.phone}</p>
      <div className="flex gap-2 mt-2"><Btn onClick={() => onEdit(e)}>Edit</Btn><Btn className="bg-red-700" onClick={() => onDelete(e)}>Delete</Btn></div>
    </Card>
  );
}
