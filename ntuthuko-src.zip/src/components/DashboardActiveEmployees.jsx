import { Card } from './ui';
export default function DashboardActiveEmployees({ entries, employees }) {
  const active = entries.filter((e) => !e.clock_out);
  return (
    <Card>
      <h2 className="font-medium mb-2">Clocked in now</h2>
      {active.length === 0 && <p className="text-sm text-gray-500">Nobody is clocked in.</p>}
      {active.map((e) => <p key={e.id} className="text-sm">{employees.find((x) => x.id === e.employee_id)?.full_name ?? 'Unknown'} since {new Date(e.clock_in).toLocaleTimeString()}</p>)}
    </Card>
  );
}
