export const today = () => new Date().toISOString().slice(0, 10);
export const hours = (e) => (e.clock_out ? (new Date(e.clock_out) - new Date(e.clock_in)) / 36e5 : 0);
export const Card = ({ className = '', ...p }) => <div className={`bg-white border rounded-lg p-4 ${className}`} {...p} />;
export const Btn = ({ className = '', ...p }) => <button className={`px-3 py-1.5 rounded bg-emerald-700 text-white text-sm disabled:opacity-50 ${className}`} {...p} />;
export const Input = ({ label, ...p }) => <label className="block text-sm mb-2">{label}<input className="block w-full border rounded px-2 py-1 mt-1" {...p} /></label>;
export const Select = ({ label, options, ...p }) => <label className="block text-sm mb-2">{label}<select className="block w-full border rounded px-2 py-1 mt-1" {...p}>{options.map((o) => <option key={o.value ?? o} value={o.value ?? o}>{o.label ?? o}</option>)}</select></label>;
export const Title = ({ children }) => <h1 className="text-2xl font-semibold mb-4">{children}</h1>;
