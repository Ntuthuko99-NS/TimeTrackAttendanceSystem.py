import { useState } from 'react';
import { Card, Btn, Input, Select } from './ui';
export default function EmployeeForm({ initial = {}, onSave, onCancel }) {
  const [f, setF] = useState({ status: 'active', ...initial });
  const set = (k) => (ev) => setF({ ...f, [k]: ev.target.value });
  return (
    <Card>
      <Input label="Full name" value={f.full_name || ''} onChange={set('full_name')} />
      <Input label="Email" type="email" value={f.email || ''} onChange={set('email')} />
      <Input label="Phone" value={f.phone || ''} onChange={set('phone')} />
      <Input label="Role" value={f.role || ''} onChange={set('role')} />
      <Input label="Department" value={f.department || ''} onChange={set('department')} />
      <Input label="Hourly rate" type="number" value={f.hourly_rate || ''} onChange={(ev) => setF({ ...f, hourly_rate: +ev.target.value })} />
      <Select label="Status" options={['active', 'inactive']} value={f.status} onChange={set('status')} />
      <div className="flex gap-2"><Btn disabled={!f.full_name || !f.email} onClick={() => onSave(f)}>Save employee</Btn>{onCancel && <Btn className="bg-gray-500" onClick={onCancel}>Cancel</Btn>}</div>
    </Card>
  );
}
