import { Card } from './ui';
export default function LeaveCalendar({ requests, month = new Date() }) {
  const y = month.getFullYear(), m = month.getMonth(), n = new Date(y, m + 1, 0).getDate();
  const iso = (d) => `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  const on = (d) => requests.filter((r) => r.status === 'approved' && r.start_date <= iso(d) && r.end_date >= iso(d)).length;
  return (
    <Card>
      <h2 className="font-medium mb-2">{month.toLocaleString('default', { month: 'long', year: 'numeric' })}</h2>
      <div className="grid grid-cols-7 gap-1 text-center text-sm">
        {Array.from({ length: n }, (_, i) => i + 1).map((d) => <div key={d} className={`border rounded p-1 ${on(d) ? 'bg-amber-100' : ''}`}>{d}{on(d) > 0 && <span className="block text-xs">{on(d)} off</span>}</div>)}
      </div>
    </Card>
  );
}
