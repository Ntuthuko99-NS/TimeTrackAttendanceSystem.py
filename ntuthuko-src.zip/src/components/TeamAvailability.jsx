import { Card, today } from './ui';
export default function TeamAvailability({ employees, entries, leave }) {
  const d = today();
  const status = (e) => {
    if (leave.some((l) => l.employee_id === e.id && l.status === 'approved' && l.start_date <= d && l.end_date >= d)) return ['On leave', 'text-amber-700'];
    if (entries.some((x) => x.employee_id === e.id && !x.clock_out)) return ['Working', 'text-emerald-700'];
    return ['Not in', 'text-gray-500'];
  };
  return (
    <Card>
      <h2 className="font-medium mb-2">Team availability</h2>
      {employees.map((e) => { const [t, cls] = status(e); return <p key={e.id} className="text-sm flex justify-between"><span>{e.full_name}</span><span className={cls}>{t}</span></p>; })}
    </Card>
  );
}
