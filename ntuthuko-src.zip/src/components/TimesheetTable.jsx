import { hours } from './ui';
export default function TimesheetTable({ entries, employees }) {
  return (
    <table className="w-full text-sm bg-white border rounded-lg">
      <thead><tr className="text-left border-b"><th className="p-2">Employee</th><th>Date</th><th>In</th><th>Out</th><th>Hours</th></tr></thead>
      <tbody>
        {entries.map((e) => (
          <tr key={e.id} className="border-b">
            <td className="p-2">{employees.find((x) => x.id === e.employee_id)?.full_name}</td>
            <td>{e.date}</td><td>{new Date(e.clock_in).toLocaleTimeString()}</td>
            <td>{e.clock_out ? new Date(e.clock_out).toLocaleTimeString() : 'Still in'}</td>
            <td>{hours(e).toFixed(2)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
