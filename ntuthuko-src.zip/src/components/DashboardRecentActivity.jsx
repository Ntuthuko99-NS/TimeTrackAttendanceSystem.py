import { Card } from './ui';
export default function DashboardRecentActivity({ entries, employees }) {
  const recent = [...entries].sort((a, b) => b.clock_in.localeCompare(a.clock_in)).slice(0, 8);
  return (
    <Card>
      <h2 className="font-medium mb-2">Recent activity</h2>
      {recent.length === 0 && <p className="text-sm text-gray-500">No time entries yet.</p>}
      {recent.map((e) => <p key={e.id} className="text-sm">{employees.find((x) => x.id === e.employee_id)?.full_name ?? 'Unknown'}: {e.clock_out ? 'clocked out' : 'clocked in'} at {new Date(e.clock_out || e.clock_in).toLocaleString()}</p>)}
    </Card>
  );
}
