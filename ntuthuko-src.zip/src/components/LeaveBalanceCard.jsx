import { Card } from './ui';
export default function LeaveBalanceCard({ requests, settings = {} }) {
  const used = (t) => requests.filter((r) => r.leave_type === t && r.status === 'approved').reduce((s, r) => s + (r.days || 0), 0);
  const rows = [['Annual', 'annual', settings.annual_leave_days ?? 15], ['Sick', 'sick', settings.sick_leave_days ?? 30]];
  return (
    <Card>
      <h2 className="font-medium mb-2">Leave balance</h2>
      {rows.map(([l, t, total]) => <p key={t} className="text-sm flex justify-between"><span>{l}</span><span>{total - used(t)} of {total} days left</span></p>)}
    </Card>
  );
}
