import { ntuthukoClient as c } from '../api/ntuthukoClient';
const Q = 'ntk_clock_queue';
const read = () => JSON.parse(localStorage.getItem(Q) || '[]');
const write = (v) => localStorage.setItem(Q, JSON.stringify(v));
export const punch = (type, employee_id) => { write([...read(), { type, employee_id, time: new Date().toISOString() }]); return sync(); };
export async function sync() {
  if (!navigator.onLine) return;
  for (const op of read()) {
    if (op.type === 'in') await c.entities.TimeEntry.create({ employee_id: op.employee_id, date: op.time.slice(0, 10), clock_in: op.time });
    else {
      const open = (await c.entities.TimeEntry.filter({ employee_id: op.employee_id })).find((e) => !e.clock_out);
      if (open) await c.entities.TimeEntry.update(open.id, { clock_out: op.time });
    }
  }
  write([]);
}
window.addEventListener('online', sync);
