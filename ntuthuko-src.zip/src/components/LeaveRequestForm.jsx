import { useState } from 'react';
import { Card, Btn, Input, Select, today } from './ui';
export default function LeaveRequestForm({ employee, onSave }) {
  const [f, setF] = useState({ leave_type: 'annual', start_date: today(), end_date: today() });
  const set = (k) => (ev) => setF({ ...f, [k]: ev.target.value });
  const days = Math.round((new Date(f.end_date) - new Date(f.start_date)) / 864e5) + 1;
  return (
    <Card>
      <Select label="Leave type" options={['annual', 'sick', 'family', 'unpaid', 'other']} value={f.leave_type} onChange={set('leave_type')} />
      <Input label="From" type="date" value={f.start_date} onChange={set('start_date')} />
      <Input label="To" type="date" value={f.end_date} onChange={set('end_date')} />
      <Input label="Reason" value={f.reason || ''} onChange={set('reason')} />
      <Btn disabled={days < 1} onClick={() => onSave({ ...f, days, employee_id: employee.id, status: 'pending' })}>Request {days > 0 ? days : 0} day(s) leave</Btn>
    </Card>
  );
}
