import { useState } from 'react';
import { Card, Btn, Input, Select, today } from './ui';
export default function ShiftForm({ employees, onSave }) {
  const [f, setF] = useState({ date: today(), start_time: '08:00', end_time: '17:00' });
  const set = (k) => (ev) => setF({ ...f, [k]: ev.target.value });
  return (
    <Card>
      <Select label="Employee" value={f.employee_id || ''} onChange={set('employee_id')} options={[{ value: '', label: 'Select employee' }, ...employees.map((e) => ({ value: e.id, label: e.full_name }))]} />
      <Input label="Date" type="date" value={f.date} onChange={set('date')} />
      <Input label="Start" type="time" value={f.start_time} onChange={set('start_time')} />
      <Input label="End" type="time" value={f.end_time} onChange={set('end_time')} />
      <Input label="Notes" value={f.notes || ''} onChange={set('notes')} />
      <Btn disabled={!f.employee_id} onClick={() => onSave(f)}>Create shift</Btn>
    </Card>
  );
}
