import { Card, Btn } from './ui';
export default function AlertPanels({ alerts, onRead }) {
  if (!alerts.length) return <p className="text-sm text-gray-500">You have no alerts.</p>;
  return alerts.map((a) => (
    <Card key={a.id} className={`flex justify-between items-center ${a.read ? 'opacity-60' : ''}`}>
      <div className="text-sm"><p>{a.message}</p><p className="text-gray-500">{a.type} - {new Date(a.created_date).toLocaleString()}</p></div>
      {!a.read && <Btn onClick={() => onRead(a)}>Mark as read</Btn>}
    </Card>
  ));
}
