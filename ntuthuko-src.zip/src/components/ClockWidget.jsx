import { useEffect, useState } from 'react';
import { ntuthukoClient as c } from '../api/ntuthukoClient';
import { Card, Btn } from './ui';
import { punch, sync } from './ClockOfflineSync';
export default function ClockWidget({ employee }) {
  const [open, setOpen] = useState(null);
  const load = async () => setOpen((await c.entities.TimeEntry.filter({ employee_id: employee.id })).find((x) => !x.clock_out) || null);
  useEffect(() => { sync().then(load); }, [employee.id]);
  const go = async () => { await punch(open ? 'out' : 'in', employee.id); load(); };
  return (
    <Card className="flex items-center justify-between">
      <p className="text-sm text-gray-600">{open ? `Clocked in since ${new Date(open.clock_in).toLocaleTimeString()}` : 'Not clocked in'}</p>
      <Btn onClick={go}>{open ? 'Clock out' : 'Clock in'}</Btn>
    </Card>
  );
}
