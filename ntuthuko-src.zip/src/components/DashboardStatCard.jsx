import { Card } from './ui';
export default function DashboardStatCard({ label, value }) {
  return <Card><p className="text-sm text-gray-500">{label}</p><p className="text-3xl font-semibold">{value}</p></Card>;
}
